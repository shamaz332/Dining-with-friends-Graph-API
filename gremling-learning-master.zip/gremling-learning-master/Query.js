const { prettierJsonForm, toObject } = require("./utils");
const { g } = require("./app");
const gremlin = require("gremlin");
// Use the anonymous traversal
const __ = gremlin.process.statics;

// #1
const getMyFriends = async (userId) => {
  try {
    const list = await g.V(userId).bothE("friends").otherV().toList();
    return list;
  } catch (err) {
    return err;
  }
};

// #2
const friendsOfFriends = async (userId) => {
  try {
    const list = await g
      .V(userId)
      .as("mee")
      .hasLabel("Person")
      .repeat(__.both("friends"))
      .times(2)
      .where(gremlin.process.P.neq("mee")) // Removing my self from list
      .valueMap(true)
      .toList();
    return list.map((obj) => {
      if (!!obj) {
        const o = prettierJsonForm(obj);
        o["uid"] = o.id;
        delete o.id;
        return o;
      } else {
        return null;
      }
    });
  } catch (err) {
    return err;
  }
};

// #3
const howPersonXYAssociated = async (userXId, userYId) => {
  try {
    const userX = 12;
    const userY = 8;
    const list = await g
      .V(userXId)
      .as("mee")
      .repeat(__.out("friends"))
      .until(__.hasId(userYId).simplePath())
      .path()
      .unfold()
      .valueMap(true)
      .where(gremlin.process.P.neq("mee")) // Removing my self from list
      // .values("username")
      .dedup()
      .toList();
    return list.map((obj) => {
      if (!!obj) {
        const o = prettierJsonForm(obj);
        o["uid"] = o.id;
        delete o.id;
        return o;
      } else {
        return null;
      }
    });
  } catch (err) {
    return err;
  }
};

// #4
const getHighestNearRestaurantsByCuisine = async (cousineName, userId) => {
  try {
    const userLatitude = 14.54345;
    const userLongitude = 23.124533;
    const list = await g
      .V()
      // .hasLabel("Cuisine")
      .has("Cuisine", "name", cousineName || "cuisine 1")
      .in_()
      .hasLabel("Restaurant")
      .order()
      .by(
        __.project("lat", "long")
          .by("cordsLatitute")
          .by("cordsLongitude")
          .math(`sqrt((lat-${userLatitude})^2 + (long-${userLongitude})^2)`)
      )
      .in_()
      .hasLabel("Review")
      .order()
      .by(
        __.inE("rated").has("helpful", true).count(),
        gremlin.process.order.desc
      )
      .out()
      .dedup()
      .valueMap(true)
      .toList();

    return list.map((obj) => {
      if (!!obj) {
        const o = prettierJsonForm(obj);
        o["restaurantId"] = o.id;
        delete o.id;
        return o;
      } else {
        return null;
      }
    });
  } catch (err) {
    return err;
  }
};

// #5
const topTenNearRestaurants = async () => {
  try {
    const list = await g
      .V()
      .hasLabel("Restaurant")
      .order()
      .by(
        __.project("lat", "long")
          .by("cordsLatitute")
          .by("cordsLongitude")
          .math("sqrt((lat-14.54345)^2 + (long-23.124533)^2)")
      )
      .limit(10)
      .valueMap(true)
      .toList();

    return list.map((obj) => {
      console.log(obj);
      if (!!obj) {
        const o = prettierJsonForm(obj);
        o["restaurantId"] = o.id;
        delete o.id;
        return o;
      } else {
        return null;
      }
    });
  } catch (err) {
    return err;
  }
};

// #6
const latestReviewsByRestaurant = async (restaurantId) => {
  try {
    const list = await g
      .V(restaurantId)
      .in_()

      .hasLabel("Review")
      .order()
      .by("createdAt", gremlin.process.order.desc)
      .dedup()
      .valueMap(true)
      .toList();

    return list.map((obj) => {
      console.log(obj);
      if (!!obj) {
        const o = prettierJsonForm(obj);
        o["reviewId"] = o.id;
        delete o.id;
        return o;
      } else {
        return null;
      }
    });
  } catch (err) {
    return err;
  }
};
// #8
const topRatedRestaurantsByFriends = async (userId) => {
  try {
    const list = await g
      .V(userId)
      .bothE("friends")
      .otherV()
      .out()
      .hasLabel("Review")
      .order()
      .by("stars", gremlin.process.order.desc)
      .dedup()
      .out()
      .hasLabel("Restaurant")
      .dedup()
      .valueMap(true)
      .toList();

    return list.map((obj) => {
      console.log(obj);
      if (!!obj) {
        const o = prettierJsonForm(obj);
        o["restaurantId"] = o.id;
        delete o.id;
        return o;
      } else {
        return null;
      }
    });
  } catch (err) {
    return err;
  }
};
// #9
const restaurantsRatedByLastXDays = async (userId, days) => {
  try {
    const lastXDays = days || 1615252017870;
    const list = await g
      .V(userId)
      .bothE("friends")
      .otherV()
      .union(
        __.outE("rated").where(
          __.values("createdAt").is(gremlin.process.P.gte(lastXDays))
        ),
        __.outE("writes").where(
          __.values("createdAt").is(gremlin.process.P.gte(lastXDays))
        )
      )
      .inV()
      .dedup()
      .out()
      .hasLabel("Restaurant")
      .dedup()
      .valueMap(true)
      .toList();

    return list.map((obj) => {
      console.log(obj);
      if (!!obj) {
        const o = prettierJsonForm(obj);
        o["restaurantId"] = o.id;
        delete o.id;
        return o;
      } else {
        return null;
      }
    });
  } catch (err) {
    return err;
  }
};
module.exports = {
  getMyFriends,
  friendsOfFriends,
  howPersonXYAssociated,
  getHighestNearRestaurantsByCuisine,
  topTenNearRestaurants,
  latestReviewsByRestaurant,
  restaurantsRatedByLastXDays,
  topRatedRestaurantsByFriends,
};
