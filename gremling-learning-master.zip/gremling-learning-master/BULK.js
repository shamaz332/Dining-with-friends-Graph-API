/*
SAVE AND GET
 [
      { username: "shahzad", email: "shahzad@gmail.com" },
      { username: "ali", email: "ali@gmail.com" },
      { username: "sheri", email: "sheri@gmail.com" },
      { username: "shamaz", email: "shamaz@gmail.com" },
      { username: "talha", email: "talha@gmail.com" },
    ].forEach(async (ob) => {
      try {
        const res = await addPerson(ob);
        console.log(res);
      } catch (err) {
        console.log("error agya bety 2-->", err);
        process.exit(1);
      }
    });
    const results = await g.V().hasLabel("Person").valueMap(true).toList();
    console.log(results);

*/
