const {
  addVertex,
  addEdge,
  hasEdgeBetweenVertices,
  removeEdgeBetweenVertices,
  prettierJsonForm,
  getTimestamp,
  lastXDaysTimestamp,
} = require("./utils");
const { g } = require("./app");
const gremlin = require("gremlin");
// Use the anonymous traversal
const __ = gremlin.process.statics;
const addPerson = async (obj) => {
  try {
    const person = await addVertex("Person", obj);
    person["uid"] = person.id;
    delete person.id;
    return person;
  } catch (err) {
    return err;
  }
};
const followPerson = async (fromVertexId, toVertexId, properties) => {
  try {
    const friendsAlready = await hasEdgeBetweenVertices(
      "friends",
      fromVertexId,
      toVertexId
    );
    console.log("friendsAlready", friendsAlready);
    if (!!friendsAlready) {
      const res = await removeEdgeBetweenVertices(
        "friends",
        fromVertexId,
        toVertexId
      );

      return "Unfollowed";
    } else {
      const friendsEdge = await addEdge(
        "friends",
        fromVertexId,
        toVertexId,
        properties
      );
      console.log(friendsEdge);
      return "followed.";
    }
  } catch (err) {
    return err;
  }
};

const addRestaurant = async (obj) => {
  try {
    const res = await addVertex("Restaurant", obj);
    res["resId"] = res.id;
    delete res.id;
    return res;
    // {
    //   label: 'Restaurant',
    //   createdAt: 1615483676920,
    //   address: '2 Miller Road',
    //   name: 'Feedspan',
    //   cordsLatitute: 8.5493413,
    //   cordsLongitude: -71.2428737,
    //   resId: 172
    // }
  } catch (err) {
    return err;
  }
};
const addCuisine = async (obj) => {
  try {
    // obj: restaurantId/name/
    const result = await g
      .V(obj.restaurantId)
      .addE("serves")
      .to(
        g
          .addV("Cuisine")
          .property("name", obj.name)
          .property("createdAt", getTimestamp())
          .as("created_cuisine")
      )
      .inV()
      .valueMap(true)
      .next();
    let clone = null;
    if (!!result.value) {
      clone = prettierJsonForm(result.value);
    }
    clone["cuisId"] = clone.id;
    delete clone.id;
    return clone;
  } catch (err) {
    return err;
  }
};
const serveCuisineByRestaurant = async (obj) => {
  try {
    // obj: restaurantId/cuisId/
    const result = await addEdge(
      "serves",
      obj.restaurantId,
      obj.cuisId,
      null,
      "IN"
    );
    return result;
  } catch (err) {
    return err;
  }
};

const writeReview = async (obj, i) => {
  try {
    // OBJ: uid/restaurantId/comment/stars/
    let res = await g
      .V(obj.uid)
      .as("as_user")
      .addV("Review")
      .property("uid", obj.uid)
      .property("comment", obj.comment)
      .property("stars", obj.stars)
      .property("createdAt", lastXDaysTimestamp(i))
      .as("as_review_to") //IT save the created Review-vertex in to alias
      .addE("writes")
      .from_(g.V(obj.uid)) // user as from: user->writes->review
      .inV() // Get the created Review.
      .valueMap(true)
      .next();

    let clone = null;
    if (!!res.value) {
      clone = prettierJsonForm(res.value);
    }

    // res.id is the reviewID
    clone["reviewId"] = clone.id;
    delete clone.id;
    const reviewLinkToRestaurant = await addEdge(
      "are-about",
      clone["reviewId"],
      obj.restaurantId
    );
    return clone;
  } catch (err) {
    return err;
  }
};

const rateReview = async (obj) => {
  try {
    // obj: uid/reviewId/helpful
    const result = await addEdge(
      "rated",
      obj.uid,
      obj.reviewId,
      {
        helpful: !!obj.helpful,
      },
      "IN"
    );
    return result;
  } catch (err) {
    return err;
  }
};

module.exports = {
  addPerson,
  followPerson,
  addRestaurant,
  writeReview,
  addCuisine,
  serveCuisineByRestaurant,
  rateReview,
};
