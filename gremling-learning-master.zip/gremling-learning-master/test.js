/**
 * 
   
    const u1 =   await addPerson({
        username: 'shahzad',
        email: "shahzad@gmail.com",
     })
    const  u2 =       await addPerson({
        username: 'shamaz',
        email: "shamaz@gmail.com",
      })
      
      const u3 = await addPerson({
        username: "ali",
        email: "ali@gmail.com",
      })
    
    const u4 = await addPerson({
        username: "usama",
        email: "usama@gmail.com",
      })

    const u5 =  await addPerson({
        username: "sheri",
        email: "sheri@gmail.com",
    })
    
    const u6= await addPerson({
        username: "yasir",
        email: "yasir@gmail.com",
      })


    console.log(await followPerson(u5.uid, u3.uid));
    console.log(await followPerson(u5.uid, u2.uid));
    console.log(await followPerson(u4.uid, u5.uid));
    console.log(await followPerson(u6.uid, u4.uid));


    
    for (const obj of restaurantMockData) { 
      console.log("result: ", await addRestaurant(obj));
    }

-------
 
    console.log(
      await addCuisine({
        name: "cuisine 1",
        restaurantId: 196, //restaurantId
      })
    );

    const rr = [208, 202, 196, 178];

    for (const resId of rr) {
      console.log(
        await serveCuisineByRestaurant({
          cuisId: 214,
          restaurantId: resId,
        })
      );
    }

------------- write Reviews Randomly --------------------

const random_comment = () => [...Array(4)].map(i=>(~~(Math.random()*36)).toString(36)).join('');

    const random_star = () => Math.ceil(Math.random()*5);

    const restaurantIds = await g.V().hasLabel("Restaurant").id().toList();
    const usersId = await g.V().hasLabel("Person").id().toList();

    const reviewsList = [];
    restaurantIds.forEach((restaurantId) => {
      usersId.forEach((uid) => {
        reviewsList.push({
          restaurantId,
          uid,
          comment:`${random_comment()}`
          helpful: random_star(),
        });
      });
    }); 
 

    for (const obj of reviewsList) {
      console.log(await writeReview(obj));
    }

------------- Rate Reviews Randomly --------------------
    const reviewIds = await g.V().hasLabel("Review").id().toList();
    const usersId = await g.V().hasLabel("Person").id().toList();

    const random_boolean = () => Math.random() < 0.5;
    const rateData = [];
    reviewIds.forEach((reviewId) => {
      usersId.forEach((uid) => {
        rateData.push({
          reviewId,
          uid,
          helpful: random_boolean(),
        });
      });
    });

    for (const obj of rateData) {
      console.log(await rateReview(obj));
    }
    



     const cuisine = "Pakora";
    const distanceOffset = 30;
    const query = this.g
      .V()
      .has("cuisine", "name", cuisine)
      .inE()
      .outV()
      .where(__.values("distance").is(gremlin.process.P.lte(distanceOffset)))
      .order()
      .by(
        __.inE().hasLabel("about").otherV().inE().hasLabel("likes").count(),
        gremlin.process.order.desc
      )
      .limit(1)
      .valueMap()
      .next();

      
 */

// For Query# 4

/**
       g.V(257).hasLabel('Review').inE('rated').valueMap(true).groupCount().by('helpful')
      result: {false:2,true:4}


       g.V().hasLabel('Review').project('review_id','true_count').by(id).by(inE('rated').has('helpful',true).count()).sort()
{review_id=257, true_count=4}
==>{review_id=264, true_count=5}
==>{review_id=271, true_count=2}
==>{review_id=278, true_count=5}


--------- Finally it give the reviews with desc order by highest helpful reviews
g.V().hasLabel('Review').order().by(inE('rated').has('helpful',true).count(), desc).valueMap(true)


       */

/**
 g.V().hasLabel('Cuisine').in()
    .hasLabel('Restaurant')
    .order()
    .by(
      values('cordsLongitute').as('lat')
      ,
      asc
    )

      RESTAURANT ORDER BY DISTANCE

    g.V()
      .hasLabel("Cuisine")
      .in()
      .hasLabel("Restaurant")
      .order()
      .by(
        project("lat", "long")
          .by("cordsLatitute")
          .by("cordsLongitude")
          .math("sqrt((lat-14.54345)^2 + (long-23.124533)^2)"),
        asc
      );
`sqrt((lat-${userLatitude})^2 + (long-${userLongitude})^2)`
      IN CONSOLE
      g.V().hasLabel('Cuisine').in().hasLabel('Restaurant').order().by(project('lat','long').by('cordsLatitute').by('cordsLongitude').math('sqrt((lat-14.54345)^2 + (long-23.124533)^2)') ,asc)


      // In experiment 
      https://github.com/krlawrence/graph/blob/master/sample-code/great-circle.groovy
      https://www.movable-type.co.uk/scripts/latlong.html
      https://stackoverflow.com/questions/59380318/measure-gps-distance-between-two-points-without-using-almost-any-math-accuracy
      
      
      const rdeg = 0.017453293;
      const gcmiles = 3956;
       g.V()
      .hasLabel("Cuisine")
      .in()
      .hasLabel("Restaurant")
      .order()
      .by(
        project("lat", "long")
          .by("cordsLatitute")
          .by("cordsLongitude")
          .math("(lat-14.54345)*0.017453293").as('ladiff')
          .math("(long-23.124533)*0.017453293").as('lgdiff')
          math('(sin(ladiff/2))^2 + cos(lat*rdeg) * cos(14.54345*rdeg) * (sin(lgdiff/2))^2').
          math('3956 * (2 * asin(sqrt(_)))')   
          
          ,
        desc
      );

  g.V().hasLabel('Cuisine').in().hasLabel('Restaurant').order().by(project('lat', 'long').by('cordsLatitute').by('cordsLongitude').math('(lat-14.54345)*0.017453293').as('ladiff').math('(long-23.124533)*0.017453293').as('lgdiff').math('(sin(ladiff/2))^2 + cos(lat*rdeg) * cos(14.54345*rdeg) * (sin(lgdiff/2))^2').math('3956 * (2 * asin(sqrt(_)))'),desc)

 */

/*
   console.log(
      await g
        .V()
        .hasLabel("Cuisine")
        .in_()
        .hasLabel("Restaurant")
        .order()
        .by(
          __.project("lat", "long")
            .by("cordsLatitute")
            .by("cordsLongitude")
            .math("sqrt((lat-14.54345)^2 + (long-23.124533)^2)")
        )
        .toList()
    );

    console.log(
      await g
        .V()
        .hasLabel("Review")
        .order()
        .by(
          __.inE("rated").has("helpful", true).count(),
          gremlin.process.order.desc
        )
        .out()
        .dedup()
        .toList()
    );
  
  
  */

/*
    
    query # 9


    g.V(12).bothE('friends').otherV().union(outE('rated').where(values('createdAt').is(gte(1615252017870))),outE('writes').where(values('createdAt').is(gte(1615252017870)))).inV().dedup().out().hasLabel('Restaurant').dedup()

    */

/*
    query 8
    
    g.V(16).bothE('friends').otherV().out().hasLabel('Review').order().by( inE('rated').values('createdAt'),desc )


    g.V(16).bothE('friends').otherV().out().hasLabel('Review').order().by('stars',desc ).dedup().out().hasLabel('Restaurant').dedup()

    
    */
