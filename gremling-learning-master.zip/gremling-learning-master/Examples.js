// GET LIST WITH DESC ORDER BY PROPERTY

/*

const res = await g
  .V()
  .hasLabel("User")
  .order()
  .by("createdAt", gremlin.process.order.desc)
  .valueMap(true)
  .toList();
const resultArray = res.map((o) => Object.fromEntries(o));

*/

// ----------------------------
// COUNT ROWS
/*
const rrr = await g.V().hasLabel("User").count().next();
console.log(rrr && rrr.value); RESULT: integer

*/

// ----------------------------
// GET SINGLE VERTEX
/*

const rrr = await g.V(68).hasLabel("User").valueMap(true).next();
console.log(Object.fromEntries(rrr.value));

*/

// ----------------------------
// FOLLOW A PERSON (ADD EDGE B/W TWO VERTICES)
/*

e.g:1
    const fromUserId = 25;
    const toUserId = 100;

    const from = await g.V(fromUserId);
    const to = g.V(toUserId);

    const res = await g.V(fromUserId).addE("friends").to(to).next();
e.g:2 
    const fromUserId = 25;
    const toUserId = 100;

    const from = g.V(fromUserId);
    const to = g.V(toUserId);

    const res = await g.addE("friends").from_(from).to(to).next();
    console.log(res);
*/

// ----------------------------
//https://stackoverflow.com/questions/52447308/add-edge-if-not-exist-using-gremlin/52447622
//https://stackoverflow.com/questions/51251768/what-is-the-equivalent-of-the-gremlin-queries-in-gremlin-javascript

// // Use the anonymous traversal
// const __ = gremlin.process.statics;

// const res = await g.addE("friends").from_(from).to(to).where().next();
// console.log(res);
// const res = await g
//   .V(fromUserId)
//   .bothE("friends")
//   .as("follows")
//   .where(gremlin.process.P.lte(__.as("follows").count()))
//   .next();
// console.log(res);

// const res = await g
//   .V(fromUserId)
//   .as("v")
//   .V(toUserId)
//   .coalesce(
//     __.inE("fdiends").where(__.outV().as("v")),
//     g.addE("friends").from_(from).to(to)
//   )
//   .next();

// ----------------------------
// 1
/*
const userId = 12;
const res = await g.V(userId).hasLabel("friends").both().valueMap(true).toList();
console.log(Object.fromEntries(rrr.value));

*/
// ----------------------------
// https://stackoverflow.com/questions/34589215/how-to-remove-edge-between-two-vertices
// Check is there edge present b/w two vertices by Id
/*
  const id_1=0;
  const id_2=4;
  const hasEdge = await g.V(id_1).bothE("friends").where(__.otherV().hasId(id_2)).hasNext()

*/

// --------------

/**
 
    console.log(
      await addRestaurant({
        name: "Pizza hut",
        address: "17 B, Dground, FSD",
        cordsLatitute: 123424235,
        cordsLongitude: 56456546,
      })
    );
    
    .addE("are-about")
    .from_(__.as("as_review")) // Review(from: as_review)->are-about->Restaurant
    .to(g.V(restaurantId))
 */

/*

    GET ALL Reviews of specific restaurant
      await g
        .V(360)
        .in_("are-about")
        .order()
        .by("createdAt", gremlin.process.order.desc)
        .valueMap(true)
        .limit(1)
        .toList()
    
    
    */
