export type Maybe<T> = T | null;
export type Exact<T extends { [key: string]: unknown }> = {
  [K in keyof T]: T[K];
};
export type MakeOptional<T, K extends keyof T> = Omit<T, K> &
  { [SubKey in K]?: Maybe<T[SubKey]> };
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> &
  { [SubKey in K]: Maybe<T[SubKey]> };
/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
  ID: string;
  String: string;
  Boolean: boolean;
  Int: number;
  Float: number;
};

export type Person = {
  __typename?: "Person";
  uid: Scalars["ID"];
  username: Scalars["String"];
  email: Scalars["String"];
  createdAt: Scalars["Int"];
  year?: Maybe<Scalars["String"]>;
};

export type Rate = {
  __typename?: "Rate";
  rateId?: Maybe<Scalars["String"]>;
  helpful?: Maybe<Scalars["Boolean"]>;
};

export type Review = {
  __typename?: "Review";
  reviewId: Scalars["ID"];
  text: Scalars["String"];
  stars: Scalars["Int"];
  createdAt: Scalars["Int"];
};

export type Cuisine = {
  __typename?: "Cuisine";
  cuisId: Scalars["ID"];
  name: Scalars["String"];
  createdAt: Scalars["Int"];
};

export type Coordinates = {
  longitute?: Maybe<Scalars["Int"]>;
  latitute?: Maybe<Scalars["Int"]>;
};

export type Restaurant = {
  __typename?: "Restaurant";
  resId: Scalars["ID"];
  name: Scalars["String"];
  address: Scalars["String"];
  location: Coordinates;
};

export type PersonInput = {
  username: Scalars["String"];
  email: Scalars["String"];
};

export type RestaurantInput = {
  name: Scalars["String"];
  address: Scalars["String"];
  longitute: Scalars["Int"];
  latitute: Scalars["Int"];
};

export type ReviewInput = {
  uid: Scalars["String"];
  text: Scalars["String"];
  stars: Scalars["Int"];
};

export type RatingInput = {
  uid: Scalars["String"];
  reviewId: Scalars["String"];
  helpful: Scalars["Boolean"];
};

export type Mutation = {
  __typename?: "Mutation";
  addPerson: Person;
  followPerson?: Maybe<Scalars["String"]>;
  addRestaurant: Restaurant;
  addCuisine: Cuisine;
  writeReview: Review;
  rateReview: Rate;
};

export type MutationAddPersonArgs = {
  data: PersonInput;
};

export type MutationFollowPersonArgs = {
  userId: Scalars["String"];
};

export type MutationAddRestaurantArgs = {
  data: RestaurantInput;
};

export type MutationAddCuisineArgs = {
  name: Scalars["String"];
};

export type MutationWriteReviewArgs = {
  data: ReviewInput;
};

export type MutationRateReviewArgs = {
  data: RatingInput;
};

export type AssociatedFriend = {
  person?: Maybe<Person>;
  message?: Maybe<Scalars["String"]>;
};

export type Query = {
  __typename?: "Query";
  getMyFriends?: Maybe<Array<Person>>;
  friendsOfFriends?: Maybe<Array<Person>>;
  isPersonXYAssociated: AssociatedFriend;
  getHighestNearRestaurantsByCuisine?: Maybe<Array<Restaurant>>;
  topTenNearRestaurants?: Maybe<Array<Restaurant>>;
  reviewsByRestaurant?: Maybe<Array<Review>>;
  restaurantsByFriendsRecommendation?: Maybe<Array<Restaurant>>;
  topRatedRestaurants?: Maybe<Array<Restaurant>>;
  restaurantsRatedByLastXDays?: Maybe<Array<Restaurant>>;
};

export type QueryGetMyFriendsArgs = {
  userId: Scalars["String"];
};

export type QueryFriendsOfFriendsArgs = {
  userId: Scalars["String"];
};

export type QueryIsPersonXyAssociatedArgs = {
  userXId: Scalars["String"];
  userYId: Scalars["String"];
};

export type QueryGetHighestNearRestaurantsByCuisineArgs = {
  cousineName: Scalars["String"];
};

export type QueryReviewsByRestaurantArgs = {
  restaurantId: Scalars["String"];
};

export type QueryRestaurantsByFriendsRecommendationArgs = {
  userId?: Maybe<Scalars["String"]>;
};

export type QueryTopRatedRestaurantsArgs = {
  userId?: Maybe<Scalars["String"]>;
};

export type QueryRestaurantsRatedByLastXDaysArgs = {
  userId?: Maybe<Scalars["String"]>;
};
