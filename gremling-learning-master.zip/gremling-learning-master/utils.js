const gremlin = require("gremlin");
// Use the anonymous traversal
const __ = gremlin.process.statics;
const { g } = require("./app");
const getTimestamp = () => new Date().getTime();
const convertObjectArrIntoParis = (obj) => {
  const keyPair = {};
  Object.entries(obj).forEach(([key, value]) => {
    if (Array.isArray(value)) {
      keyPair[key] = value[0];
    } else {
      keyPair[key] = value;
    }
  });
  return keyPair;
};
const prettierJsonForm = (obj) => {
  const a = Object.fromEntries(obj);
  return convertObjectArrIntoParis(a);
};
const addVertex = async (label, obj) => {
  try {
    let query = g.addV(label);
    const createdAt = getTimestamp();
    Object.entries({ ...obj, createdAt }).forEach(([key, value], i) => {
      query = query.property(key, value);
    });

    let result = await query.valueMap(true).next();
    result = convertObjectArrIntoParis(Object.fromEntries(result.value));
    return result;
  } catch (err) {
    console.log("error agya bety", err);
    return err;
  }
};

//returnType: out/in/null
const addEdge = async (
  label,
  fromVertexId,
  toVertexId,
  properties,
  returnType
) => {
  try {
    const createdAt = getTimestamp();

    const fromVertex = g.V(fromVertexId);
    const toVertex = g.V(toVertexId);
    let query = g.addE(`${label}`).from_(fromVertex).to(toVertex);

    if (properties) {
      Object.entries({ ...properties, createdAt }).forEach(
        ([key, value], i) => {
          query = query.property(key, value);
        }
      );
    }
    if (returnType === "OUT") {
      query = query.outV();
    } else if (returnType === "IN") {
      query = query.inV();
    }
    const result = await query.valueMap(true).next();
    const cloned = !!result.value ? prettierJsonForm(result.value) : null;
    return cloned;
  } catch (err) {
    console.log("error agya bety", err);
    return err;
  }
};

const getSingleVertexById = async (label, id) => {
  try {
    let res = await g.V(id).hasLabel(label).valueMap(true).next();
    if (res.value) {
      res =
        res.value && convertObjectArrIntoParis(Object.fromEntries(res.value));
    } else {
      res = res.value;
    }
    return res;
  } catch (err) {
    return err;
  }
};
const getSingleEdgeById = async (label, id) => {
  try {
    let res = await g.E().hasLabel(label).valueMap(true).next();
    if (res.value) {
      res =
        res.value && convertObjectArrIntoParis(Object.fromEntries(res.value));
    } else {
      res = res.value;
    }
    return res;
  } catch (err) {
    return err;
  }
};

const hasEdgeBetweenVertices = async (label, vId_1, vId_2) => {
  try {
    const hasEdge = await g
      .V(vId_1)
      .bothE(label)
      .where(__.otherV().hasId(vId_2))
      .hasNext();
    return hasEdge;
  } catch (err) {
    return err;
  }
};
const removeEdgeBetweenVertices = async (label, vId_1, vId_2) => {
  try {
    const hasEdge = await g
      .V(vId_1)
      .bothE(label)
      .where(__.otherV().hasId(vId_2))
      .drop()
      .next();
    return hasEdge;
  } catch (err) {
    return err;
  }
};

const toObject = (pairs) => {
  return Array.from(pairs).reduce(
    (acc, [key, value]) => Object.assign(acc, { [key]: value }),
    {}
  );
};
const lastXDaysTimestamp = (days) => {
  let d = new Date();
  d.setDate(d.getDate() - 10);
  const ms = d.getTime();
  return ms;
};
module.exports = {
  addVertex,
  addEdge,
  getSingleVertexById,
  getSingleEdgeById,
  hasEdgeBetweenVertices,
  removeEdgeBetweenVertices,
  prettierJsonForm,
  getTimestamp,
  toObject,
  lastXDaysTimestamp,
};
