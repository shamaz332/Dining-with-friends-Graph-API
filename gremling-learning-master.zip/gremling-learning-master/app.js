const gremlin = require("gremlin");
const graph = new gremlin.structure.Graph();
const DriverRemoteConnection = gremlin.driver.DriverRemoteConnection;
const connection = new DriverRemoteConnection(
  "ws://localhost:8182/gremlin",
  {}
);

const g = graph.traversal().withRemote(connection);
exports.g = g;
const restaurantMockData = require("./restaurant.json");

// Use the anonymous traversal
const __ = gremlin.process.statics;
const {
  hasEdgeBetweenVertices,
  removeEdgeBetweenVertices,
  getSingleVertexById,
} = require("./utils");
const {
  addPerson,
  followPerson,
  addRestaurant,
  writeReview,
  addCuisine,
  serveCuisineByRestaurant,
  rateReview,
} = require("./Mutations");
const {
  getMyFriends,
  friendsOfFriends,
  howPersonXYAssociated,
  getHighestNearRestaurantsByCuisine,
  topTenNearRestaurants,
  latestReviewsByRestaurant,
  restaurantsRatedByLastXDays,
  topRatedRestaurantsByFriends,
} = require("./Query");

const getTimestamp = () => new Date().getTime();

(async () => {
  try {
    // console.log(await g.V().hasLabel("Person").valueMap(true).toList());
    console.log(await howPersonXYAssociated(8, 12));
    process.exit(0);
  } catch (err) {
    console.log(err);
  }
})();
